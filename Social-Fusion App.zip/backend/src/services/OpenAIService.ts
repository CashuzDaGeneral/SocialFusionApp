import OpenAI from 'openai';
import { logger } from '../utils/logger';

class OpenAIService {
  private openai: OpenAI;

  constructor() {
    this.openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY
    });
  }

  async enhanceContent(content: string, platform: string) {
    try {
      const response = await this.openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          {
            role: "system",
            content: `You are a social media expert specializing in ${platform}. 
                     Enhance the given content to maximize engagement and virality while maintaining authenticity.
                     Consider the platform's specific characteristics and user behavior patterns.`
          },
          {
            role: "user",
            content: content
          }
        ],
        temperature: 0.7,
        max_tokens: 1000
      });

      const enhancedContent = response.choices[0].message.content || '';
      const viralScore = this.calculateViralityScore(enhancedContent, platform);
      const hashtags = await this.generateHashtags(content, platform);

      return {
        enhancedContent,
        viralScore,
        hashtags
      };
    } catch (error) {
      logger.error('OpenAI enhancement error:', error);
      throw new Error('Content enhancement failed');
    }
  }

  private calculateViralityScore(content: string, platform: string): number {
    // Implement sophisticated virality scoring algorithm
    // Consider platform-specific factors, content length, hashtag usage, etc.
    return 85; // Placeholder
  }

  private async generateHashtags(content: string, platform: string): Promise<string[]> {
    try {
      const response = await this.openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          {
            role: "system",
            content: `Generate 5 trending and relevant hashtags for ${platform} based on the content.`
          },
          {
            role: "user",
            content: content
          }
        ],
        temperature: 0.7
      });

      const hashtagText = response.choices[0].message.content || '';
      return hashtagText.match(/#[\w]+/g) || [];
    } catch (error) {
      logger.error('Hashtag generation error:', error);
      return [];
    }
  }
}

export default new OpenAIService();