import React from 'react';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../contexts/AuthContext';
import { BarChart, Calendar, Users, Activity } from 'lucide-react';
import { motion } from 'framer-motion';

const DashboardPage = () => {
  const { t } = useTranslation();
  const { currentUser } = useAuth();

  const stats = [
    { icon: Users, label: 'followers', value: '5,234' },
    { icon: Activity, label: 'engagement', value: '12.3%' },
    { icon: Calendar, label: 'scheduledPosts', value: '8' },
    { icon: BarChart, label: 'totalReach', value: '25.4K' }
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold mb-2">
          {t('dashboard.welcome', { name: currentUser?.displayName })}
        </h1>
        <p className="text-gray-600">{t('dashboard.overview')}</p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-lg shadow-md p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <Icon className="w-8 h-8 text-blue-600" />
                <span className="text-2xl font-bold">{stat.value}</span>
              </div>
              <h3 className="text-gray-600">{t(`dashboard.stats.${stat.label}`)}</h3>
            </motion.div>
          );
        })}
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white rounded-lg shadow-md p-6"
        >
          <h2 className="text-xl font-bold mb-4">{t('dashboard.recentActivity')}</h2>
          {/* Add recent activity component */}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white rounded-lg shadow-md p-6"
        >
          <h2 className="text-xl font-bold mb-4">{t('dashboard.upcomingPosts')}</h2>
          {/* Add upcoming posts component */}
        </motion.div>
      </div>
    </div>
  );
};

export default DashboardPage;