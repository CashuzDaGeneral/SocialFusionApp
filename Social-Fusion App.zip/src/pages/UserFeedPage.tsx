import React from 'react';

const UserFeedPage = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Your Feed</h1>
      {/* Add user's social media feed aggregation here */}
    </div>
  );
};

export default UserFeedPage;