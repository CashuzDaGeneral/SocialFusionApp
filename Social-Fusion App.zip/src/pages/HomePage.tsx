import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Linkedin, Youtube, ChevronRight, Twitch } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import PostingService from '../services/PostingService';

const TikTokIcon = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
    <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z" />
  </svg>
);

const BiGoIcon = () => (
  <span className="text-2xl font-bold">BiGo</span>
);

const socialPlatforms = [
  { name: 'Facebook', icon: Facebook, color: 'bg-blue-600' },
  { name: 'Twitter', icon: Twitter, color: 'bg-sky-500' },
  { name: 'Instagram', icon: Instagram, color: 'bg-pink-600' },
  { name: 'LinkedIn', icon: Linkedin, color: 'bg-blue-700' },
  { name: 'YouTube', icon: Youtube, color: 'bg-red-600' },
  { name: 'TikTok', icon: TikTokIcon, color: 'bg-black' },
  { name: 'Twitch', icon: Twitch, color: 'bg-purple-600' },
  { name: 'BiGo Live', icon: BiGoIcon, color: 'bg-green-500' },
];

const StarField: React.FC<{ count?: number }> = ({ count = 300 }) => {
  return (
    <div className="absolute inset-0">
      {Array.from({ length: count }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full bg-white"
          style={{
            width: Math.random() * 2 + 1,
            height: Math.random() * 2 + 1,
            top: `${Math.random() * 100}%`,
            left: `${Math.random() * 100}%`,
          }}
          animate={{
            opacity: [0.2, 1, 0.2],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: Math.random() * 2 + 8,
            repeat: Infinity,
            repeatType: "reverse",
          }}
        />
      ))}
    </div>
  );
};

const Nebula: React.FC = () => {
  return (
    <div className="absolute inset-0 overflow-hidden">
      <motion.div
        className="absolute top-0 left-0 w-full h-full bg-gradient-radial from-blue-500/30 via-purple-500/20 to-transparent opacity-70"
        animate={{ rotate: [0, 360] }}
        transition={{ duration: 400, repeat: Infinity, ease: "linear" }}
      />
    </div>
  );
};

const HomePage = () => {
  const [hoveredPlatform, setHoveredPlatform] = useState<string | null>(null);
  const { t } = useTranslation();

  return (
    <div className="relative min-h-screen overflow-hidden bg-gradient-to-br from-purple-900 to-indigo-800 text-white">
      <StarField />
      <Nebula />

      <header className="p-4 flex justify-between items-center relative z-10">
        <h1 className="text-2xl font-bold">Social Fusion</h1>
        <nav>
          <Link to="/" className="text-white hover:text-purple-300 px-3 py-2">Home</Link>
          <Link to="/features" className="text-white hover:text-purple-300 px-3 py-2">Features</Link>
          <Link to="/pricing" className="text-white hover:text-purple-300 px-3 py-2">Pricing</Link>
          <Link to="/contact" className="text-white hover:text-purple-300 px-3 py-2">Contact</Link>
        </nav>
      </header>

      <main className="container mx-auto px-4 py-16 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-bold mb-4">{t('home.title')}</h2>
          <p className="text-xl mb-8">{t('home.subtitle')}</p>
          <Link to="/auth" className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-3 rounded-full text-lg font-semibold transition-colors duration-300">
            {t('home.getStarted')}
          </Link>
        </div>

        <div className="mt-16 text-center">
          <h3 className="text-3xl font-bold mb-6">{t('home.experience')}</h3>
          <div className="relative w-[80vw] h-[80vw] max-w-[800px] max-h-[800px] mx-auto">
            <div className="absolute inset-0 flex items-center justify-center">
              <img
                src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
                alt="Earth view from space"
                className="rounded-full w-[60%] h-[60%] object-cover"
              />
            </div>
            
            {socialPlatforms.map((platform, index) => {
              const angle = (index / socialPlatforms.length) * Math.PI * 2;
              const radius = 46;
              const x = Math.cos(angle) * radius;
              const y = Math.sin(angle) * radius;

              return (
                <motion.div
                  key={platform.name}
                  className={`absolute rounded-full p-2 cursor-pointer ${platform.color}`}
                  style={{
                    left: `${50 + x}%`,
                    top: `${50 + y}%`,
                    transform: 'translate(-50%, -50%)',
                  }}
                  whileHover={{ scale: 1.25, zIndex: 10 }}
                  onHoverStart={() => setHoveredPlatform(platform.name)}
                  onHoverEnd={() => setHoveredPlatform(null)}
                >
                  {typeof platform.icon === 'function' ? (
                    <platform.icon />
                  ) : (
                    <platform.icon className="w-8 h-8 text-white" />
                  )}
                  {hoveredPlatform === platform.name && (
                    <motion.div
                      className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 px-2 py-1 bg-white text-black text-xs rounded shadow-lg"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.3 }}
                    >
                      {platform.name}
                    </motion.div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center mt-16">
          <div>
            <h3 className="text-3xl font-bold mb-6">{t('home.platforms')}</h3>
            <div className="grid grid-cols-3 gap-4">
              {socialPlatforms.map((platform) => (
                <motion.div
                  key={platform.name}
                  className={`${platform.color} p-4 rounded-lg flex flex-col items-center justify-center cursor-pointer transition-all duration-300`}
                  whileHover={{ scale: 1.05 }}
                >
                  {typeof platform.icon === 'function' ? (
                    <platform.icon />
                  ) : (
                    <platform.icon size={40} />
                  )}
                  <span className="mt-2 font-medium">{platform.name}</span>
                </motion.div>
              ))}
            </div>
          </div>
          <div>
            <h3 className="text-3xl font-bold mb-6">{t('home.features')}</h3>
            <ul className="space-y-4">
              {['unifiedDashboard', 'contentScheduling', 'analytics', 'teamCollaboration', 'aiPoweredInsights', 'multiPlatformStreaming'].map((feature) => (
                <motion.li
                  key={feature}
                  className="flex items-center space-x-2"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <ChevronRight className="text-purple-400" />
                  <span>{t(`home.featureList.${feature}`)}</span>
                </motion.li>
              ))}
            </ul>
          </div>
        </div>
      </main>

      <footer className="mt-16 bg-purple-900 py-8 text-center relative z-10">
        <p>&copy; 2024 Social Fusion. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default HomePage;