import React from 'react';
import ContentScheduler from '../components/ContentScheduler';

const SchedulePostsPage = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Schedule Posts</h1>
      <ContentScheduler />
    </div>
  );
};

export default SchedulePostsPage;