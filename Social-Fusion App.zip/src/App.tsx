import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import HomePage from './pages/HomePage';
import ExplorePage from './pages/ExplorePage';
import SchedulePostsPage from './pages/SchedulePostsPage';
import ProfilePage from './pages/ProfilePage';
import UserFeedPage from './pages/UserFeedPage';
import LiveStreamingPortal from './pages/LiveStreamingPortal';
import CreatePostPage from './pages/CreatePostPage';
import AuthPage from './pages/AuthPage';
import AnalyticsDashboard from './pages/AnalyticsDashboard';
import SettingsPage from './pages/SettingsPage';
import DashboardPage from './pages/DashboardPage';
import Header from './components/Header';
import Footer from './components/Footer';
import SkipToMain from './components/SkipToMain';
import AccessibilityMenu from './components/AccessibilityMenu';
import { AuthProvider } from './contexts/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import './i18n';

function App() {
  const { t } = useTranslation();

  return (
    <AuthProvider>
      <Router>
        <div className="flex flex-col min-h-screen bg-gray-100">
          <SkipToMain />
          <Header />
          <main id="main" className="flex-grow container mx-auto px-4 py-8" role="main">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/auth" element={<AuthPage />} />
              <Route element={<ProtectedRoute />}>
                <Route path="/dashboard" element={<DashboardPage />} />
                <Route path="/explore" element={<ExplorePage />} />
                <Route path="/schedule" element={<SchedulePostsPage />} />
                <Route path="/profile" element={<ProfilePage />} />
                <Route path="/feed" element={<UserFeedPage />} />
                <Route path="/live" element={<LiveStreamingPortal />} />
                <Route path="/create" element={<CreatePostPage />} />
                <Route path="/analytics" element={<AnalyticsDashboard />} />
                <Route path="/settings" element={<SettingsPage />} />
              </Route>
            </Routes>
          </main>
          <AccessibilityMenu />
          <Footer />
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;