import * as yup from 'yup';

export const userSchema = yup.object({
  email: yup.string().email('Invalid email').required('Email is required'),
  password: yup
    .string()
    .min(8, 'Password must be at least 8 characters')
    .required('Password is required'),
  displayName: yup.string().min(2, 'Name must be at least 2 characters')
});

export const postSchema = yup.object({
  content: yup
    .string()
    .required('Content is required')
    .max(2000, 'Content must be less than 2000 characters'),
  platforms: yup
    .array()
    .of(yup.string())
    .min(1, 'Select at least one platform')
    .required('Platforms are required')
});

export const streamSettingsSchema = yup.object({
  title: yup.string().required('Stream title is required'),
  description: yup.string(),
  platforms: yup
    .array()
    .of(yup.string())
    .min(1, 'Select at least one platform')
    .required('Platforms are required')
});