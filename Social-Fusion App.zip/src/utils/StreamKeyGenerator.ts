import crypto from 'crypto';

class StreamKeyGenerator {
  static generate(): string {
    return crypto.randomBytes(16).toString('hex');
  }

  static validate(key: string): boolean {
    // Implement validation logic here
    return key.length === 32 && /^[0-9a-f]+$/.test(key);
  }
}

export default StreamKeyGenerator;