import React, { useState, useEffect } from 'react';
import { Video, Mic, MicOff, Camera, CameraOff } from 'lucide-react';
import StreamKeyGenerator from '../utils/StreamKeyGenerator';
import MultiStreamHandler from './MultiStreamHandler';

const StreamingService = () => {
  const [isLive, setIsLive] = useState(false);
  const [streamKey, setStreamKey] = useState('');
  const [selectedPlatforms, setSelectedPlatforms] = useState([]);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [videoEnabled, setVideoEnabled] = useState(true);
  const [streamSettings, setStreamSettings] = useState({});
  const [analytics, setAnalytics] = useState({});

  useEffect(() => {
    if (isLive) {
      const key = StreamKeyGenerator.generate();
      setStreamKey(key);
      MultiStreamHandler.startStream(key, selectedPlatforms, streamSettings);
      startAnalyticsPolling(key);
    } else {
      if (streamKey) {
        MultiStreamHandler.stopStream(streamKey);
        stopAnalyticsPolling();
      }
      setStreamKey('');
    }
  }, [isLive]);

  const startAnalyticsPolling = (key) => {
    const interval = setInterval(() => {
      const streamAnalytics = MultiStreamHandler.getStreamAnalytics(key);
      setAnalytics(streamAnalytics);
    }, 5000);
    return () => clearInterval(interval);
  };

  const stopAnalyticsPolling = () => {
    // Implement stopping the analytics polling
  };

  const toggleLiveStream = () => {
    setIsLive(!isLive);
  };

  const toggleAudio = () => {
    setAudioEnabled(!audioEnabled);
    if (isLive) {
      MultiStreamHandler.toggleAudio(streamKey, !audioEnabled);
    }
  };

  const toggleVideo = () => {
    setVideoEnabled(!videoEnabled);
    if (isLive) {
      MultiStreamHandler.toggleVideo(streamKey, !videoEnabled);
    }
  };

  const handlePlatformSelection = (platform) => {
    if (selectedPlatforms.includes(platform)) {
      setSelectedPlatforms(selectedPlatforms.filter(p => p !== platform));
    } else {
      setSelectedPlatforms([...selectedPlatforms, platform]);
    }
  };

  const handleStreamSettingsChange = (platform, setting, value) => {
    setStreamSettings(prev => ({
      ...prev,
      [platform]: {
        ...prev[platform],
        [setting]: value
      }
    }));
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center mb-4">
        <Video className="w-6 h-6 mr-2 text-blue-600" />
        <h2 className="text-2xl font-semibold">Live Streaming</h2>
      </div>
      
      <div className="mb-4">
        <h3 className="text-lg font-semibold mb-2">Select Platforms</h3>
        <div className="flex flex-wrap gap-2">
          {['Facebook', 'YouTube', 'Twitch', 'TikTok', 'Instagram', 'LinkedIn', 'Twitter', 'BiGo Live'].map(platform => (
            <button
              key={platform}
              onClick={() => handlePlatformSelection(platform)}
              className={`px-3 py-1 rounded ${
                selectedPlatforms.includes(platform)
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 text-gray-800'
              }`}
            >
              {platform}
            </button>
          ))}
        </div>
      </div>
      
      {selectedPlatforms.map(platform => (
        <div key={platform} className="mb-4">
          <h4 className="font-semibold">{platform} Settings</h4>
          <input
            type="text"
            placeholder="Stream Title"
            onChange={(e) => handleStreamSettingsChange(platform, 'title', e.target.value)}
            className="w-full px-3 py-2 border rounded mt-2"
          />
          <textarea
            placeholder="Stream Description"
            onChange={(e) => handleStreamSettingsChange(platform, 'description', e.target.value)}
            className="w-full px-3 py-2 border rounded mt-2"
          />
        </div>
      ))}
      
      <div className="flex items-center space-x-4 mb-4">
        <button
          onClick={toggleAudio}
          className={`p-2 rounded-full ${audioEnabled ? 'bg-blue-100' : 'bg-red-100'}`}
        >
          {audioEnabled ? <Mic className="text-blue-600" /> : <MicOff className="text-red-600" />}
        </button>
        <button
          onClick={toggleVideo}
          className={`p-2 rounded-full ${videoEnabled ? 'bg-blue-100' : 'bg-red-100'}`}
        >
          {videoEnabled ? <Camera className="text-blue-600" /> : <CameraOff className="text-red-600" />}
        </button>
      </div>
      
      <button
        onClick={toggleLiveStream}
        className={`w-full py-2 px-4 rounded-lg font-semibold ${
          isLive ? 'bg-red-600 text-white' : 'bg-blue-600 text-white'
        }`}
        disabled={selectedPlatforms.length === 0}
      >
        {isLive ? 'End Stream' : 'Go Live'}
      </button>
      
      {isLive && (
        <div className="mt-4">
          <h3 className="text-lg font-semibold mb-2">Stream Key</h3>
          <p className="bg-gray-100 p-2 rounded">{streamKey}</p>
          <p className="text-sm text-gray-600 mt-1">
            Use this key to set up your stream in your preferred streaming software.
          </p>
          
          <h3 className="text-lg font-semibold mt-4 mb-2">Live Analytics</h3>
          {Object.entries(analytics).map(([platform, data]) => (
            <div key={platform} className="mb-2">
              <h4 className="font-semibold">{platform}</h4>
              <p>Viewers: {data.viewers}</p>
              <p>Likes: {data.likes}</p>
              <p>Comments: {data.comments}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default StreamingService;