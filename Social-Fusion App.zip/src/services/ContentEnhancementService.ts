import OpenAI from 'openai';
import apiClient from '../utils/ApiClient';

class ContentEnhancementService {
  async enhanceContent(content: string, platform: string): Promise<{
    enhancedContent: string;
    viralScore: number;
    hashtags: string[];
  }> {
    try {
      const response = await apiClient.post('/api/content/enhance', {
        content,
        platform
      });
      return response;
    } catch (error) {
      console.error('Error enhancing content:', error);
      throw new Error('Failed to enhance content');
    }
  }

  async getViralityScore(content: string, platform: string): Promise<number> {
    try {
      const response = await apiClient.post('/api/content/virality-score', {
        content,
        platform
      });
      return response.score;
    } catch (error) {
      console.error('Error getting virality score:', error);
      throw new Error('Failed to calculate virality score');
    }
  }

  async suggestHashtags(content: string, platform: string): Promise<string[]> {
    try {
      const response = await apiClient.post('/api/content/suggest-hashtags', {
        content,
        platform
      });
      return response.hashtags;
    } catch (error) {
      console.error('Error suggesting hashtags:', error);
      throw new Error('Failed to suggest hashtags');
    }
  }
}

export default new ContentEnhancementService();