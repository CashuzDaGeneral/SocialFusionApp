import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-wrap justify-between">
          <div className="w-full md:w-1/4 mb-6 md:mb-0">
            <h3 className="text-xl font-semibold mb-4">Social Fusion</h3>
            <p>Your all-in-one social media management and amplification platform.</p>
          </div>
          <div className="w-full md:w-1/4 mb-6 md:mb-0">
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul>
              <li><a href="/about" className="hover:text-blue-400">About Us</a></li>
              <li><a href="/features" className="hover:text-blue-400">Features</a></li>
              <li><a href="/pricing" className="hover:text-blue-400">Pricing</a></li>
              <li><a href="/contact" className="hover:text-blue-400">Contact</a></li>
            </ul>
          </div>
          <div className="w-full md:w-1/4 mb-6 md:mb-0">
            <h4 className="text-lg font-semibold mb-4">Legal</h4>
            <ul>
              <li><a href="/terms" className="hover:text-blue-400">Terms of Service</a></li>
              <li><a href="/privacy" className="hover:text-blue-400">Privacy Policy</a></li>
            </ul>
          </div>
          <div className="w-full md:w-1/4">
            <h4 className="text-lg font-semibold mb-4">Connect With Us</h4>
            {/* Add social media icons here */}
          </div>
        </div>
        <div className="mt-8 text-center">
          <p>&copy; 2023 Social Fusion. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;