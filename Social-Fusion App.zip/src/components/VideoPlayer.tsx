import React, { useRef, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

interface VideoPlayerProps {
  src: string;
  captions?: string;
  title: string;
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({ src, captions, title }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const { t } = useTranslation();
  const [showCaptions, setShowCaptions] = useState(true);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    // Add keyboard controls
    const handleKeyPress = (e: KeyboardEvent) => {
      switch (e.key) {
        case ' ':
          e.preventDefault();
          video.paused ? video.play() : video.pause();
          break;
        case 'ArrowRight':
          video.currentTime += 5;
          break;
        case 'ArrowLeft':
          video.currentTime -= 5;
          break;
        case 'ArrowUp':
          video.volume = Math.min(1, video.volume + 0.1);
          break;
        case 'ArrowDown':
          video.volume = Math.max(0, video.volume - 0.1);
          break;
      }
    };

    document.addEventListener('keydown', handleKeyPress);
    return () => document.removeEventListener('keydown', handleKeyPress);
  }, []);

  return (
    <div className="video-player relative" role="region" aria-label={title}>
      <video
        ref={videoRef}
        className="w-full"
        controls
        aria-label={title}
      >
        <source src={src} type="video/mp4" />
        {captions && showCaptions && (
          <track
            kind="captions"
            src={captions}
            srcLang="en"
            label="English"
            default
          />
        )}
        {t('accessibility.videoNotSupported')}
      </video>

      {/* Accessible Controls */}
      <div className="video-controls mt-2 flex items-center space-x-4" role="group" aria-label={t('accessibility.videoControls')}>
        <button
          onClick={() => setShowCaptions(!showCaptions)}
          className="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
          aria-pressed={showCaptions}
        >
          {showCaptions ? t('accessibility.hideCaptions') : t('accessibility.showCaptions')}
        </button>

        <div className="text-sm text-gray-600">
          {t('accessibility.keyboardControls')}:
          <ul className="ml-2">
            <li>Space - {t('accessibility.playPause')}</li>
            <li>← → - {t('accessibility.seekVideo')}</li>
            <li>↑ ↓ - {t('accessibility.adjustVolume')}</li>
          </ul>
        </div>
      </div>

      {/* Audio Description Track (if available) */}
      <audio id="audio-description" className="hidden">
        <source src="path-to-audio-description.mp3" type="audio/mpeg" />
      </audio>
    </div>
  );
};

export default VideoPlayer;