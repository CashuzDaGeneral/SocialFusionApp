import React, { useState } from 'react';
import { Edit3, Upload, Calendar } from 'lucide-react';
import PostingService from '../services/PostingService';
import PlatformIcon from './PlatformIcons';
import { useTranslation } from 'react-i18next';

const PostingPortal: React.FC = () => {
  const { t } = useTranslation();
  const [content, setContent] = useState('');
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [mediaFiles, setMediaFiles] = useState<File[]>([]);
  const [isScheduling, setIsScheduling] = useState(false);
  const [scheduledTime, setScheduledTime] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState('');

  const handlePlatformToggle = (platformId: string) => {
    setSelectedPlatforms(prev =>
      prev.includes(platformId)
        ? prev.filter(p => p !== platformId)
        : [...prev, platformId]
    );
  };

  const handleMediaUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      setMediaFiles(Array.from(event.target.files));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage('');

    try {
      const mediaUrls = []; // In a real app, upload files and get URLs
      
      if (isScheduling && scheduledTime) {
        const result = await PostingService.schedulePost(
          content,
          selectedPlatforms,
          new Date(scheduledTime),
          mediaUrls
        );
        setMessage(result.success ? t('posting.scheduleSuccess') : result.message);
      } else {
        const result = await PostingService.createPost(
          content,
          selectedPlatforms,
          mediaUrls
        );
        setMessage(result.success ? t('posting.postSuccess') : result.message);
      }

      if (result.success) {
        setContent('');
        setSelectedPlatforms([]);
        setMediaFiles([]);
        setScheduledTime('');
      }
    } catch (error) {
      setMessage(t('posting.error'));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center mb-6">
        <Edit3 className="w-6 h-6 text-blue-600 mr-2" />
        <h2 className="text-2xl font-semibold">{t('posting.title')}</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {t('posting.selectPlatforms')}
          </label>
          <div className="flex flex-wrap gap-3">
            {PostingService.getSupportedPlatforms().map(platform => (
              <button
                key={platform.id}
                type="button"
                onClick={() => handlePlatformToggle(platform.id)}
                className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
                  selectedPlatforms.includes(platform.id)
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <PlatformIcon platform={platform.id} className="w-5 h-5 mr-2" />
                <span>{platform.name}</span>
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {t('posting.content')}
          </label>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
            rows={4}
            placeholder={t('posting.contentPlaceholder')}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {t('posting.media')}
          </label>
          <div className="flex items-center space-x-4">
            <label className="flex items-center px-4 py-2 bg-gray-100 rounded-lg cursor-pointer hover:bg-gray-200">
              <Upload className="w-5 h-5 mr-2" />
              <span>{t('posting.uploadMedia')}</span>
              <input
                type="file"
                multiple
                accept="image/*,video/*"
                onChange={handleMediaUpload}
                className="hidden"
              />
            </label>
            {mediaFiles.length > 0 && (
              <span className="text-sm text-gray-600">
                {mediaFiles.length} {t('posting.filesSelected')}
              </span>
            )}
          </div>
        </div>

        <div>
          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={isScheduling}
              onChange={(e) => setIsScheduling(e.target.checked)}
              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <span className="text-sm font-medium text-gray-700">
              {t('posting.schedulePost')}
            </span>
          </label>

          {isScheduling && (
            <input
              type="datetime-local"
              value={scheduledTime}
              onChange={(e) => setScheduledTime(e.target.value)}
              className="mt-2 block w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
            />
          )}
        </div>

        {message && (
          <div className={`p-4 rounded-lg ${
            message.includes('success')
              ? 'bg-green-100 text-green-700'
              : 'bg-red-100 text-red-700'
          }`}>
            {message}
          </div>
        )}

        <button
          type="submit"
          disabled={isLoading || !content || selectedPlatforms.length === 0}
          className="w-full flex items-center justify-center px-4 py-2 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
        >
          {isLoading ? t('common.loading') : (
            isScheduling ? t('posting.schedule') : t('posting.post')
          )}
        </button>
      </form>
    </div>
  );
};

export default PostingPortal;