import React, { useState } from 'react';
import AmpifireService from '../services/AmpifireService';

const AmpifireIntegration: React.FC = () => {
  const [content, setContent] = useState('');
  const [contentType, setContentType] = useState<'article' | 'video' | 'infographic'>('article');
  const [platforms, setPlatforms] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const handleCreateAndDistribute = async () => {
    setLoading(true);
    try {
      const createdContent = await AmpifireService.createContent(content, contentType);
      const distributionResult = await AmpifireService.distributeContent(createdContent.id, platforms);
      setResult(distributionResult);
    } catch (error) {
      console.error('Error in AmpiFire process:', error);
      setResult({ error: 'Failed to process content with AmpiFire' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white shadow-md rounded-lg p-6">
      <h2 className="text-2xl font-bold mb-4">AmpiFire Content Amplification</h2>
      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="Enter your content here"
        className="w-full p-2 border rounded mb-4"
        rows={4}
      />
      <select
        value={contentType}
        onChange={(e) => setContentType(e.target.value as 'article' | 'video' | 'infographic')}
        className="w-full p-2 border rounded mb-4"
      >
        <option value="article">Article</option>
        <option value="video">Video</option>
        <option value="infographic">Infographic</option>
      </select>
      <div className="mb-4">
        <h3 className="font-semibold mb-2">Select Platforms</h3>
        {['Facebook', 'Twitter', 'LinkedIn', 'Medium', 'WordPress'].map(platform => (
          <label key={platform} className="block">
            <input
              type="checkbox"
              checked={platforms.includes(platform)}
              onChange={() => {
                if (platforms.includes(platform)) {
                  setPlatforms(platforms.filter(p => p !== platform));
                } else {
                  setPlatforms([...platforms, platform]);
                }
              }}
            /> {platform}
          </label>
        ))}
      </div>
      <button
        onClick={handleCreateAndDistribute}
        disabled={loading || !content || platforms.length === 0}
        className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 disabled:bg-gray-400"
      >
        {loading ? 'Processing...' : 'Create and Distribute Content'}
      </button>
      {result && (
        <div className="mt-4">
          <h3 className="font-semibold">Result:</h3>
          <pre className="bg-gray-100 p-2 rounded mt-2 overflow-x-auto">
            {JSON.stringify(result, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
};

export default AmpifireIntegration;