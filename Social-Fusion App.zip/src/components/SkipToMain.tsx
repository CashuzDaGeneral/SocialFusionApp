import React from 'react';
import { useTranslation } from 'react-i18next';

const SkipToMain = () => {
  const { t } = useTranslation();

  return (
    <a href="#main" className="skip-to-main">
      {t('accessibility.skipToMain')}
    </a>
  );
};

export default SkipToMain;