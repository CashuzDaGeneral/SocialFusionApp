import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Settings, Eye, Volume2, Type } from 'lucide-react';

const AccessibilityMenu: React.FC = () => {
  const { t, i18n } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const [fontSize, setFontSize] = useState(100);
  const [highContrast, setHighContrast] = useState(false);
  const [screenReader, setScreenReader] = useState(false);
  const [closedCaptions, setClosedCaptions] = useState(false);

  useEffect(() => {
    document.documentElement.style.fontSize = `${fontSize}%`;
    if (highContrast) {
      document.documentElement.classList.add('high-contrast');
    } else {
      document.documentElement.classList.remove('high-contrast');
    }
  }, [fontSize, highContrast]);

  const languages = [
    { code: 'en', name: 'English' },
    { code: 'es', name: 'Español' },
    { code: 'fr', name: 'Français' },
    { code: 'zh', name: '中文' },
    { code: 'ar', name: 'العربية' }
  ];

  const changeFontSize = (increment: number) => {
    setFontSize(prev => Math.min(Math.max(prev + increment, 80), 150));
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-4 right-4 bg-blue-600 text-white p-3 rounded-full shadow-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 z-50"
        aria-label={t('accessibility.menuButton')}
      >
        <Settings className="w-6 h-6" />
      </button>

      {isOpen && (
        <div className="fixed bottom-20 right-4 bg-white rounded-lg shadow-xl p-4 w-72 z-50" role="dialog" aria-label={t('accessibility.menu')}>
          <h2 className="text-lg font-semibold mb-4">{t('accessibility.settings')}</h2>

          <div className="space-y-4">
            {/* Language Selection */}
            <div>
              <label className="block text-sm font-medium mb-1">{t('accessibility.language')}</label>
              <select
                value={i18n.language}
                onChange={(e) => i18n.changeLanguage(e.target.value)}
                className="w-full rounded border-gray-300"
              >
                {languages.map(({ code, name }) => (
                  <option key={code} value={code}>{name}</option>
                ))}
              </select>
            </div>

            {/* Font Size Controls */}
            <div>
              <label className="block text-sm font-medium mb-1">
                <Type className="inline w-4 h-4 mr-1" />
                {t('accessibility.fontSize')}
              </label>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => changeFontSize(-10)}
                  className="px-2 py-1 bg-gray-200 rounded"
                  aria-label={t('accessibility.decreaseFontSize')}
                >
                  A-
                </button>
                <span>{fontSize}%</span>
                <button
                  onClick={() => changeFontSize(10)}
                  className="px-2 py-1 bg-gray-200 rounded"
                  aria-label={t('accessibility.increaseFontSize')}
                >
                  A+
                </button>
              </div>
            </div>

            {/* High Contrast Mode */}
            <div className="flex items-center justify-between">
              <label className="flex items-center text-sm font-medium">
                <Eye className="w-4 h-4 mr-1" />
                {t('accessibility.highContrast')}
              </label>
              <button
                onClick={() => setHighContrast(!highContrast)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full ${highContrast ? 'bg-blue-600' : 'bg-gray-200'}`}
                role="switch"
                aria-checked={highContrast}
              >
                <span className={`inline-block w-4 h-4 transform rounded-full bg-white transition ${highContrast ? 'translate-x-6' : 'translate-x-1'}`} />
              </button>
            </div>

            {/* Screen Reader Optimization */}
            <div className="flex items-center justify-between">
              <label className="flex items-center text-sm font-medium">
                <Volume2 className="w-4 h-4 mr-1" />
                {t('accessibility.screenReader')}
              </label>
              <button
                onClick={() => setScreenReader(!screenReader)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full ${screenReader ? 'bg-blue-600' : 'bg-gray-200'}`}
                role="switch"
                aria-checked={screenReader}
              >
                <span className={`inline-block w-4 h-4 transform rounded-full bg-white transition ${screenReader ? 'translate-x-6' : 'translate-x-1'}`} />
              </button>
            </div>

            {/* Closed Captions */}
            <div className="flex items-center justify-between">
              <label className="flex items-center text-sm font-medium">
                <Volume2 className="w-4 h-4 mr-1" />
                {t('accessibility.closedCaptions')}
              </label>
              <button
                onClick={() => setClosedCaptions(!closedCaptions)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full ${closedCaptions ? 'bg-blue-600' : 'bg-gray-200'}`}
                role="switch"
                aria-checked={closedCaptions}
              >
                <span className={`inline-block w-4 h-4 transform rounded-full bg-white transition ${closedCaptions ? 'translate-x-6' : 'translate-x-1'}`} />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AccessibilityMenu;