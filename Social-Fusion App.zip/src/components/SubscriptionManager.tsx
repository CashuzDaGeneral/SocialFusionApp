import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import AuthService from '../services/AuthService';

const SubscriptionManager: React.FC = () => {
  const { currentUser } = useAuth();
  const [currentTier, setCurrentTier] = useState<string>('free');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUserTier = async () => {
      if (currentUser) {
        const tier = await AuthService.getUserTier(currentUser.uid);
        setCurrentTier(tier);
        setLoading(false);
      }
    };
    fetchUserTier();
  }, [currentUser]);

  const handleUpgrade = async (newTier: string) => {
    if (currentUser) {
      // Here you would typically integrate with a payment processor
      // For this example, we'll just update the tier directly
      await AuthService.upgradeUserTier(currentUser.uid, newTier);
      setCurrentTier(newTier);
    }
  };

  if (loading) {
    return <div>Loading subscription info...</div>;
  }

  return (
    <div className="bg-white shadow-md rounded-lg p-6">
      <h2 className="text-2xl font-bold mb-4">Your Subscription</h2>
      <p className="mb-4">Current Tier: <span className="font-semibold">{currentTier}</span></p>
      
      {currentTier === 'free' && (
        <div>
          <button 
            onClick={() => handleUpgrade('basic')}
            className="bg-blue-500 text-white px-4 py-2 rounded mr-2 hover:bg-blue-600"
          >
            Upgrade to Basic ($9.99/month)
          </button>
          <button 
            onClick={() => handleUpgrade('premium')}
            className="bg-purple-500 text-white px-4 py-2 rounded mr-2 hover:bg-purple-600"
          >
            Upgrade to Premium ($24.99/month)
          </button>
        </div>
      )}
      
      {currentTier === 'basic' && (
        <button 
          onClick={() => handleUpgrade('premium')}
          className="bg-purple-500 text-white px-4 py-2 rounded hover:bg-purple-600"
        >
          Upgrade to Premium ($24.99/month)
        </button>
      )}
      
      {currentTier === 'premium' && (
        <button 
          onClick={() => handleUpgrade('elite')}
          className="bg-gold-500 text-white px-4 py-2 rounded hover:bg-gold-600"
        >
          Upgrade to Elite ($49.99/month)
        </button>
      )}
    </div>
  );
};

export default SubscriptionManager;