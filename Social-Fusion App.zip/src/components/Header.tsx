import React from 'react';
import { Link } from 'react-router-dom';
import { Zap } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useTranslation } from 'react-i18next';

const Header = () => {
  const { currentUser, logout } = useAuth();
  const { t } = useTranslation();

  const handleLogout = async () => {
    try {
      await logout();
    } catch (error) {
      console.error('Failed to log out', error);
    }
  };

  return (
    <header className="bg-purple-900 text-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link to="/" className="flex items-center text-2xl font-bold">
          <Zap className="w-8 h-8 mr-2" />
          Social Fusion
        </Link>
        
        <nav>
          <ul className="flex space-x-6 items-center">
            <li>
              <Link to="/" className="hover:text-purple-300 transition-colors">
                {t('header.home')}
              </Link>
            </li>
            <li>
              <Link to="/features" className="hover:text-purple-300 transition-colors">
                {t('header.features')}
              </Link>
            </li>
            <li>
              <Link to="/pricing" className="hover:text-purple-300 transition-colors">
                {t('header.pricing')}
              </Link>
            </li>
            <li>
              <Link to="/contact" className="hover:text-purple-300 transition-colors">
                {t('header.contact')}
              </Link>
            </li>
            {currentUser ? (
              <>
                <li>
                  <Link 
                    to="/dashboard" 
                    className="bg-purple-700 hover:bg-purple-600 px-4 py-2 rounded-lg transition-colors"
                  >
                    Dashboard
                  </Link>
                </li>
                <li>
                  <button 
                    onClick={handleLogout}
                    className="hover:text-purple-300 transition-colors"
                  >
                    Logout
                  </button>
                </li>
              </>
            ) : (
              <>
                <li>
                  <Link 
                    to="/auth" 
                    className="hover:text-purple-300 transition-colors"
                  >
                    {t('header.login')}
                  </Link>
                </li>
                <li>
                  <Link 
                    to="/auth?signup=true" 
                    className="bg-purple-600 hover:bg-purple-500 px-4 py-2 rounded-lg transition-colors"
                  >
                    {t('header.signup')}
                  </Link>
                </li>
              </>
            )}
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;