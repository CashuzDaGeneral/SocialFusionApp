import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../firebase';
import { doc, getDoc, updateDoc, setDoc } from 'firebase/firestore';

const ReferralProgram: React.FC = () => {
  const { currentUser } = useAuth();
  const [referralCode, setReferralCode] = useState('');
  const [referralCount, setReferralCount] = useState(0);
  const [earnings, setEarnings] = useState(0);

  useEffect(() => {
    const fetchReferralInfo = async () => {
      if (currentUser) {
        const userRef = doc(db, 'users', currentUser.uid);
        const userSnap = await getDoc(userRef);
        
        if (userSnap.exists()) {
          const userData = userSnap.data();
          setReferralCode(userData.referralCode || '');
          setReferralCount(userData.referralCount || 0);
          setEarnings(userData.referralEarnings || 0);
        } else {
          // If user document doesn't exist, create it with a new referral code
          const newReferralCode = generateReferralCode();
          await setDoc(userRef, {
            referralCode: newReferralCode,
            referralCount: 0,
            referralEarnings: 0
          }, { merge: true });
          setReferralCode(newReferralCode);
        }
      }
    };

    fetchReferralInfo();
  }, [currentUser]);

  const generateReferralCode = () => {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  };

  const copyReferralLink = () => {
    const referralLink = `https://socialfusion.com/signup?ref=${referralCode}`;
    navigator.clipboard.writeText(referralLink);
    alert('Referral link copied to clipboard!');
  };

  return (
    <div className="bg-white shadow-md rounded-lg p-6">
      <h2 className="text-2xl font-bold mb-4">Referral Program</h2>
      <p className="mb-4">Share your referral code and earn rewards when new users sign up!</p>
      <div className="bg-gray-100 p-4 rounded mb-4">
        <p className="font-semibold">Your Referral Code:</p>
        <p className="text-2xl font-bold">{referralCode}</p>
        <button 
          onClick={copyReferralLink}
          className="mt-2 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
        >
          Copy Referral Link
        </button>
      </div>
      <div className="mb-4">
        <p>Total Referrals: <span className="font-bold">{referralCount}</span></p>
        <p>Total Earnings: <span className="font-bold">${earnings.toFixed(2)}</span></p>
      </div>
      <p className="text-sm text-gray-600">
        Earn $5 for each new user who signs up using your referral code and upgrades to a paid plan.
      </p>
    </div>
  );
};

export default ReferralProgram;