import { Router } from 'express';
import { authenticate } from '../middleware/security';
import StripeService from '../services/StripeService';
import { logger } from '../utils/logger';

const router = Router();

router.post('/create-subscription', authenticate, async (req, res) => {
  try {
    const { priceId } = req.body;
    const userId = req.user!.uid;

    // Get or create Stripe customer
    let customer = await StripeService.getCustomerByUserId(userId);
    if (!customer) {
      const user = await getUserData(userId); // Implement this function
      customer = await StripeService.createCustomer(user.email, user.displayName);
    }

    const subscription = await StripeService.createSubscription(
      customer.id,
      priceId
    );

    res.json(subscription);
  } catch (error) {
    logger.error('Create subscription error:', error);
    res.status(500).json({ error: 'Failed to create subscription' });
  }
});

router.post('/update-subscription', authenticate, async (req, res) => {
  try {
    const { subscriptionId, newPriceId } = req.body;
    const subscription = await StripeService.updateSubscription(
      subscriptionId,
      newPriceId
    );
    res.json(subscription);
  } catch (error) {
    logger.error('Update subscription error:', error);
    res.status(500).json({ error: 'Failed to update subscription' });
  }
});

router.post('/cancel-subscription', authenticate, async (req, res) => {
  try {
    const { subscriptionId } = req.body;
    const subscription = await StripeService.cancelSubscription(subscriptionId);
    res.json(subscription);
  } catch (error) {
    logger.error('Cancel subscription error:', error);
    res.status(500).json({ error: 'Failed to cancel subscription' });
  }
});

router.get('/payment-methods/:customerId', authenticate, async (req, res) => {
  try {
    const { customerId } = req.params;
    const paymentMethods = await StripeService.getPaymentMethods(customerId);
    res.json(paymentMethods);
  } catch (error) {
    logger.error('Get payment methods error:', error);
    res.status(500).json({ error: 'Failed to fetch payment methods' });
  }
});

router.post('/add-payment-method', authenticate, async (req, res) => {
  try {
    const { paymentMethodId, customerId } = req.body;
    const paymentMethod = await StripeService.attachPaymentMethod(
      paymentMethodId,
      customerId
    );
    res.json(paymentMethod);
  } catch (error) {
    logger.error('Add payment method error:', error);
    res.status(500).json({ error: 'Failed to add payment method' });
  }
});

router.post('/webhook', async (req, res) => {
  const sig = req.headers['stripe-signature'];
  
  try {
    const event = stripe.webhooks.constructEvent(
      req.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
    
    await StripeService.handleWebhookEvent(event);
    res.json({ received: true });
  } catch (error) {
    logger.error('Webhook error:', error);
    res.status(400).json({ error: 'Webhook error' });
  }
});

export default router;