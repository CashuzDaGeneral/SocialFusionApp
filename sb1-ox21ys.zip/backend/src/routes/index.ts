import { Express } from 'express';
import streamRoutes from './streamRoutes';
import postRoutes from './postRoutes';
import analyticsRoutes from './analyticsRoutes';
import authRoutes from './authRoutes';

export const setupRoutes = (app: Express) => {
  app.use('/api/streams', streamRoutes);
  app.use('/api/posts', postRoutes);
  app.use('/api/analytics', analyticsRoutes);
  app.use('/api/auth', authRoutes);
};