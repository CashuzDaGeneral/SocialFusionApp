import { logger } from '../utils/logger';
import { StreamPlatform, StreamSettings } from '../types/streaming';

class StreamingService {
  private activeStreams: Map<string, StreamInfo> = new Map();
  private platformHandlers: Map<string, PlatformStreamHandler> = new Map();

  constructor() {
    // Initialize platform-specific handlers
    this.initializePlatformHandlers();
  }

  private initializePlatformHandlers() {
    // Initialize handlers for each supported platform
    this.platformHandlers.set('facebook', new FacebookStreamHandler());
    this.platformHandlers.set('youtube', new YouTubeStreamHandler());
    this.platformHandlers.set('twitch', new TwitchStreamHandler());
    // Add more platform handlers
  }

  async startMultiStream(userId: string, settings: StreamSettings): Promise<string> {
    try {
      const streamId = this.generateStreamId();
      const streamInfo = new StreamInfo(userId, settings);

      // Initialize streams for each selected platform
      for (const platform of settings.platforms) {
        const handler = this.platformHandlers.get(platform);
        if (!handler) {
          throw new Error(`Unsupported platform: ${platform}`);
        }

        await handler.startStream(streamId, settings[platform]);
        streamInfo.addPlatformStream(platform);
      }

      this.activeStreams.set(streamId, streamInfo);
      return streamId;
    } catch (error) {
      logger.error('Failed to start multi-stream:', error);
      throw new Error('Failed to start streaming');
    }
  }

  async stopStream(streamId: string): Promise<void> {
    try {
      const streamInfo = this.activeStreams.get(streamId);
      if (!streamInfo) {
        throw new Error('Stream not found');
      }

      // Stop streaming on all active platforms
      for (const platform of streamInfo.getActivePlatforms()) {
        const handler = this.platformHandlers.get(platform);
        await handler?.stopStream(streamId);
      }

      this.activeStreams.delete(streamId);
    } catch (error) {
      logger.error('Failed to stop stream:', error);
      throw new Error('Failed to stop streaming');
    }
  }

  async getStreamAnalytics(streamId: string): Promise<StreamAnalytics> {
    try {
      const streamInfo = this.activeStreams.get(streamId);
      if (!streamInfo) {
        throw new Error('Stream not found');
      }

      const analytics: StreamAnalytics = {};
      for (const platform of streamInfo.getActivePlatforms()) {
        const handler = this.platformHandlers.get(platform);
        analytics[platform] = await handler?.getAnalytics(streamId);
      }

      return analytics;
    } catch (error) {
      logger.error('Failed to get stream analytics:', error);
      throw new Error('Failed to retrieve analytics');
    }
  }

  private generateStreamId(): string {
    return `stream_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

export default new StreamingService();