import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Google, 
  Facebook, 
  Twitter, 
  Instagram, 
  Linkedin, 
  Youtube, 
  Lock,
  ArrowRight
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const socialPlatforms = [
  { 
    name: 'Google',
    icon: Google,
    providers: ['google'],
    color: 'bg-red-600 hover:bg-red-700',
    description: 'YouTube and other Google services'
  },
  { 
    name: 'Facebook',
    icon: Facebook,
    providers: ['facebook'],
    color: 'bg-blue-600 hover:bg-blue-700',
    description: 'Facebook & Instagram'
  },
  { 
    name: 'Twitter',
    icon: Twitter,
    providers: ['google', 'twitter'],
    color: 'bg-sky-500 hover:bg-sky-600',
    description: 'Twitter/X platform'
  },
  { 
    name: 'LinkedIn',
    icon: Linkedin,
    providers: ['linkedin'],
    color: 'bg-blue-700 hover:bg-blue-800',
    description: 'Professional network'
  },
  { 
    name: 'YouTube',
    icon: Youtube,
    providers: ['google'],
    color: 'bg-red-700 hover:bg-red-800',
    description: 'Video content platform'
  }
];

const AuthPage = () => {
  const navigate = useNavigate();
  const { signInWithGoogle, signInWithFacebook } = useAuth();
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [connectedPlatforms, setConnectedPlatforms] = useState<string[]>([]);

  const handleAuth = async (platform: string, providers: string[]) => {
    try {
      setError('');
      setLoading(true);

      for (const provider of providers) {
        if (provider === 'google') {
          await signInWithGoogle();
        } else if (provider === 'facebook') {
          await signInWithFacebook();
        }
      }

      setConnectedPlatforms([...connectedPlatforms, platform]);

      // If this is the first platform being connected, navigate to dashboard
      if (connectedPlatforms.length === 0) {
        navigate('/dashboard');
      }
    } catch (err) {
      console.error(err);
      setError(`Failed to connect to ${platform}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-900 to-indigo-800 py-12 px-4 sm:px-6 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full space-y-8 bg-white p-8 rounded-xl shadow-2xl"
      >
        <div className="text-center">
          <Lock className="mx-auto h-12 w-12 text-purple-600" />
          <h2 className="mt-6 text-3xl font-extrabold text-gray-900">
            Connect Your Accounts
          </h2>
          <p className="mt-2 text-sm text-gray-600">
            Choose the platforms you want to manage
          </p>
        </div>

        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg relative">
            {error}
          </div>
        )}

        <div className="mt-8 space-y-4">
          {socialPlatforms.map((platform) => {
            const Icon = platform.icon;
            const isConnected = connectedPlatforms.includes(platform.name);

            return (
              <motion.div
                key={platform.name}
                whileHover={{ scale: 1.02 }}
                className={`relative rounded-lg border ${
                  isConnected ? 'border-green-500 bg-green-50' : 'border-gray-200'
                }`}
              >
                <button
                  onClick={() => handleAuth(platform.name, platform.providers)}
                  disabled={loading || isConnected}
                  className={`w-full flex items-center justify-between px-4 py-4 ${
                    isConnected ? 'cursor-default' : ''
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${platform.color}`}>
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                    <div className="text-left">
                      <p className="font-semibold text-gray-900">
                        {platform.name}
                        {isConnected && 
                          <span className="ml-2 text-green-600 text-sm">
                            Connected
                          </span>
                        }
                      </p>
                      <p className="text-sm text-gray-500">{platform.description}</p>
                    </div>
                  </div>
                  {!isConnected && <ArrowRight className="w-5 h-5 text-gray-400" />}
                </button>
              </motion.div>
            );
          })}
        </div>

        {connectedPlatforms.length > 0 && (
          <div className="mt-6">
            <button
              onClick={() => navigate('/dashboard')}
              className="w-full flex items-center justify-center px-4 py-3 border border-transparent text-base font-medium rounded-lg text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 transition-colors duration-200"
            >
              Continue to Dashboard
            </button>
          </div>
        )}

        <div className="mt-4 text-center">
          <p className="text-sm text-gray-600">
            By continuing, you agree to our{' '}
            <a href="/terms" className="font-medium text-purple-600 hover:text-purple-500">
              Terms of Service
            </a>{' '}
            and{' '}
            <a href="/privacy" className="font-medium text-purple-600 hover:text-purple-500">
              Privacy Policy
            </a>
          </p>
        </div>
      </motion.div>
    </div>
  );
};

export default AuthPage;