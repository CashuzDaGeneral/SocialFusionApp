import React from 'react';
import { motion } from 'framer-motion';
import { 
  Zap, Globe, Video, BarChart2, Brain, Users, Clock, Shield,
  MessageSquare, Rocket, Database, Award
} from 'lucide-react';

const features = [
  {
    icon: Globe,
    title: "Multi-Platform Management",
    description: "Connect and manage all your social media accounts from one unified dashboard. Support for Facebook, Twitter, Instagram, LinkedIn, YouTube, TikTok, Twitch, and BiGo Live."
  },
  {
    icon: Video,
    title: "Advanced Live Streaming",
    description: "Stream simultaneously to multiple platforms with our innovative multi-streaming technology. Control quality, manage chat, and monitor analytics in real-time."
  },
  {
    icon: BarChart2,
    title: "Comprehensive Analytics",
    description: "Get detailed insights across all platforms with our advanced analytics dashboard. Track engagement, growth, and ROI with easy-to-understand visualizations."
  },
  {
    icon: Brain,
    title: "AI-Powered Content Enhancement",
    description: "Leverage our AI technology to optimize your content for each platform, generate engaging captions, and identify trending hashtags."
  },
  {
    icon: Users,
    title: "Team Collaboration",
    description: "Seamlessly work with team members through role-based access control, content approval workflows, and real-time collaboration tools."
  },
  {
    icon: Clock,
    title: "Smart Scheduling",
    description: "Schedule posts at optimal times with our AI-powered timing recommendations. Maintain consistent presence across all platforms effortlessly."
  },
  {
    icon: Shield,
    title: "Enterprise-Grade Security",
    description: "Protect your social media assets with advanced security features including 2FA, audit logs, and encrypted data storage."
  },
  {
    icon: MessageSquare,
    title: "Unified Inbox",
    description: "Manage all your social media interactions in one place. Never miss an important message or comment across any platform."
  },
  {
    icon: Rocket,
    title: "Performance Optimization",
    description: "Get AI-powered recommendations to improve your content's performance and reach across different platforms."
  },
  {
    icon: Database,
    title: "Content Library",
    description: "Centralized asset management for all your media files with advanced search and organization capabilities."
  },
  {
    icon: Award,
    title: "Premium Support",
    description: "24/7 priority support with dedicated account managers for Elite tier subscribers."
  }
];

const FeaturesPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-bold text-gray-900 mb-4"
          >
            Powerful Features for Modern Social Media Management
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-gray-600"
          >
            Everything you need to manage, grow, and optimize your social media presence
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow"
            >
              <div className="flex items-center mb-4">
                <feature.icon className="w-8 h-8 text-purple-600 mr-3" />
                <h3 className="text-xl font-semibold text-gray-900">{feature.title}</h3>
              </div>
              <p className="text-gray-600">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FeaturesPage;