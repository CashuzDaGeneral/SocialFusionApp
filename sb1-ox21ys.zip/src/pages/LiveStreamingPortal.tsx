import React from 'react';
import StreamingService from '../services/StreamingService';

const LiveStreamingPortal = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Live Streaming Portal</h1>
      <StreamingService />
    </div>
  );
};

export default LiveStreamingPortal;