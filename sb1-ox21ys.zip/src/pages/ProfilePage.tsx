import React from 'react';

const ProfilePage = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Your Profile</h1>
      {/* Add user profile information and connected accounts here */}
    </div>
  );
};

export default ProfilePage;