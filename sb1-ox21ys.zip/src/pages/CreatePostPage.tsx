import React from 'react';
import PostingPortal from '../components/PostingPortal';

const CreatePostPage = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Create Post</h1>
      <PostingPortal />
    </div>
  );
};

export default CreatePostPage;