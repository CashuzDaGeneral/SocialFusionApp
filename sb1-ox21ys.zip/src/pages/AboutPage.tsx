import React from 'react';
import { motion } from 'framer-motion';
import { Building2, Mail, Globe, Target, Eye } from 'lucide-react';

const AboutPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-4">About Us</h1>
          <div className="flex flex-col space-y-4 items-center justify-center text-gray-600">
            <div className="flex items-center">
              <Building2 className="w-5 h-5 mr-2 text-purple-600" />
              <span>Aurea Arx Ventures LLC</span>
            </div>
            <div className="flex items-center">
              <Mail className="w-5 h-5 mr-2 text-purple-600" />
              <a href="mailto:aureaarxventures@gmail.com" className="hover:text-purple-600">
                aureaarxventures@gmail.com
              </a>
            </div>
            <div className="flex items-center">
              <Globe className="w-5 h-5 mr-2 text-purple-600" />
              <a href="http://www.aureaarxventuresllc.com" target="_blank" rel="noopener noreferrer" className="hover:text-purple-600">
                www.aureaarxventuresllc.com
              </a>
            </div>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-2xl shadow-xl p-8 mb-8"
        >
          <div className="flex items-center mb-4">
            <Target className="w-8 h-8 text-purple-600 mr-3" />
            <h2 className="text-2xl font-bold text-gray-900">Our Mission</h2>
          </div>
          <p className="text-gray-600 leading-relaxed">
            Our company is committed to empowering underdeveloped neighborhoods by investing in small businesses 
            that drive local economic growth and social progress. Through strategic investments, mentorship, 
            and tailored support, we aim to foster sustainable development, create opportunities, and build 
            resilient communities. By championing entrepreneurship and innovation in these underserved areas, 
            we strive to unlock the full potential of individuals and businesses, catalyzing positive change 
            and long-term prosperity for all stakeholders involved.
          </p>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-2xl shadow-xl p-8"
        >
          <div className="flex items-center mb-4">
            <Eye className="w-8 h-8 text-purple-600 mr-3" />
            <h2 className="text-2xl font-bold text-gray-900">Our Vision</h2>
          </div>
          <p className="text-gray-600 leading-relaxed">
            Empowering dreams, transforming communities. Our mission at Aurea Arx Ventures is to ignite 
            economic growth and social change by investing in the people and small businesses in underdeveloped 
            neighborhoods to push positive change. Through strategic partnerships and innovative solutions, 
            we aim to foster entrepreneurship, create sustainable employment opportunities, and drive positive 
            impact, ultimately paving the way for brighter futures and thriving communities worldwide.
          </p>
        </motion.div>
      </div>
    </div>
  );
};

export default AboutPage;