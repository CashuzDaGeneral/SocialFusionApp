import React from 'react';
import { motion } from 'framer-motion';
import { Check, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';

const tiers = [
  {
    name: 'Basic',
    price: '$9.99',
    trialDays: 7,
    features: [
      'Access to 1 additional social media account',
      'Basic live streaming',
      'Standard customer support',
      'Basic analytics dashboard',
      'Content scheduling',
      'Mobile app access'
    ]
  },
  {
    name: 'Premium',
    price: '$24.99',
    trialDays: 14,
    popular: true,
    features: [
      'Access to 2 additional social media accounts',
      'Advanced live streaming options',
      'Priority customer support',
      'Advanced analytics',
      'AI-powered content suggestions',
      'Team collaboration tools',
      'Custom branded streams',
      'Priority streaming quality'
    ]
  },
  {
    name: 'Elite',
    price: '$49.99',
    trialDays: 30,
    features: [
      'Unlimited social media account connections',
      'Comprehensive live streaming tools',
      'Premium 24/7 support',
      'Full access to AI enhancements',
      'Advanced analytics and reporting',
      'Custom integrations',
      'Dedicated account manager',
      'White-label solutions',
      'API access',
      'Enterprise-grade security'
    ]
  }
];

const PricingPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-bold text-gray-900 mb-4"
          >
            Choose the Perfect Plan for Your Needs
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-gray-600"
          >
            Start with a free trial and scale as you grow
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {tiers.map((tier, index) => (
            <motion.div
              key={tier.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`bg-white rounded-2xl shadow-xl p-8 relative ${
                tier.popular ? 'border-2 border-purple-500' : ''
              }`}
            >
              {tier.popular && (
                <div className="absolute top-0 right-0 bg-purple-500 text-white px-4 py-1 rounded-bl-lg rounded-tr-lg text-sm font-medium">
                  Most Popular
                </div>
              )}
              
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{tier.name}</h3>
                <p className="text-4xl font-bold text-gray-900 mb-2">{tier.price}<span className="text-lg text-gray-600">/month</span></p>
                <p className="text-gray-600">{tier.trialDays}-day free trial</p>
              </div>

              <ul className="space-y-4 mb-8">
                {tier.features.map((feature) => (
                  <li key={feature} className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-2" />
                    <span className="text-gray-600">{feature}</span>
                  </li>
                ))}
              </ul>

              <Link
                to="/auth?signup=true"
                className={`block w-full py-3 px-4 rounded-lg text-center font-semibold ${
                  tier.popular
                    ? 'bg-purple-600 text-white hover:bg-purple-700'
                    : 'bg-purple-100 text-purple-600 hover:bg-purple-200'
                } transition-colors`}
              >
                Start {tier.trialDays}-Day Free Trial
              </Link>
            </motion.div>
          ))}
        </div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-16 bg-purple-100 rounded-2xl p-8 text-center"
        >
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Referral Program</h2>
          <p className="text-gray-600 mb-4">
            Earn recurring revenue by referring friends and family to Social Fusion.
            Get a percentage of their subscription fee every month!
          </p>
          <Link
            to="/auth?signup=true"
            className="inline-flex items-center px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
          >
            <Zap className="w-5 h-5 mr-2" />
            Join Our Referral Program
          </Link>
        </motion.div>
      </div>
    </div>
  );
};

export default PricingPage;