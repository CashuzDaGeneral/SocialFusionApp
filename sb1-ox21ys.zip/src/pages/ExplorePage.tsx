import React from 'react';

const ExplorePage = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Explore Content</h1>
      {/* Add content discovery and trending topics components here */}
    </div>
  );
};

export default ExplorePage;