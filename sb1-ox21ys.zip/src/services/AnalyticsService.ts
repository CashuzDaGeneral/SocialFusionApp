import { db } from '../firebase';
import { collection, query, where, getDocs, Timestamp } from 'firebase/firestore';

class AnalyticsService {
  async getPostPerformance(postId: string) {
    const analyticsRef = collection(db, 'postAnalytics');
    const q = query(analyticsRef, where('postId', '==', postId));
    const querySnapshot = await getDocs(q);
    
    if (!querySnapshot.empty) {
      return querySnapshot.docs[0].data();
    }
    return null;
  }

  async getAccountGrowth(userId: string, timeRange: 'week' | 'month' | 'year') {
    const userRef = collection(db, 'users', userId, 'followers');
    const now = new Date();
    let startDate;

    switch (timeRange) {
      case 'week':
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case 'month':
        startDate = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate());
        break;
      case 'year':
        startDate = new Date(now.getFullYear() - 1, now.getMonth(), now.getDate());
        break;
    }

    const q = query(userRef, where('followDate', '>=', Timestamp.fromDate(startDate)));
    const querySnapshot = await getDocs(q);
    
    return querySnapshot.size; // Number of new followers in the given time range
  }

  async getEngagementRate(userId: string, platform: string) {
    // This is a simplified calculation. In a real-world scenario, you'd need to
    // fetch more detailed data and perform more complex calculations.
    const postsRef = collection(db, 'users', userId, 'posts');
    const q = query(postsRef, where('platform', '==', platform));
    const querySnapshot = await getDocs(q);

    let totalEngagements = 0;
    let totalReach = 0;

    querySnapshot.forEach((doc) => {
      const data = doc.data();
      totalEngagements += (data.likes || 0) + (data.comments || 0) + (data.shares || 0);
      totalReach += data.reach || 0;
    });

    return totalReach > 0 ? (totalEngagements / totalReach) * 100 : 0;
  }

  // Add more analytics methods as needed
}

export default new AnalyticsService();