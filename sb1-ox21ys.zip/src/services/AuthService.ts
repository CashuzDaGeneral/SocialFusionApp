import { auth, db } from '../firebase';
import { signInWithPopup, OAuthProvider, User, linkWithPopup } from 'firebase/auth';
import { doc, setDoc, getDoc, updateDoc } from 'firebase/firestore';

class AuthService {
  async signInWithOAuth(provider: string): Promise<User | null> {
    try {
      const authProvider = this.getOAuthProvider(provider);
      const result = await signInWithPopup(auth, authProvider);
      await this.updateUserProfile(result.user);
      return result.user;
    } catch (error) {
      console.error('OAuth Sign-in Error:', error);
      return null;
    }
  }

  async linkSocialAccount(provider: string): Promise<boolean> {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error('No user logged in');

      const authProvider = this.getOAuthProvider(provider);
      await linkWithPopup(user, authProvider);
      await this.updateUserProfile(user);
      return true;
    } catch (error) {
      console.error('Link account error:', error);
      return false;
    }
  }

  private getOAuthProvider(provider: string): OAuthProvider {
    switch (provider) {
      case 'google':
        return new OAuthProvider('google.com');
      case 'facebook':
        return new OAuthProvider('facebook.com');
      case 'twitter':
        return new OAuthProvider('twitter.com');
      default:
        throw new Error('Unsupported provider');
    }
  }

  private async updateUserProfile(user: User): Promise<void> {
    const userRef = doc(db, 'users', user.uid);
    const userSnap = await getDoc(userRef);

    if (userSnap.exists()) {
      await updateDoc(userRef, {
        lastLogin: new Date(),
        // Add any other fields you want to update
      });
    } else {
      await setDoc(userRef, {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName,
        photoURL: user.photoURL,
        createdAt: new Date(),
        lastLogin: new Date(),
        tier: 'free', // Default tier
        connectedAccounts: [],
      });
    }
  }

  async getUserTier(userId: string): Promise<string> {
    const userRef = doc(db, 'users', userId);
    const userSnap = await getDoc(userRef);
    if (userSnap.exists()) {
      return userSnap.data().tier;
    }
    return 'free'; // Default to free tier if not found
  }

  async upgradeUserTier(userId: string, newTier: string): Promise<void> {
    const userRef = doc(db, 'users', userId);
    await updateDoc(userRef, { tier: newTier });
  }
}

export default new AuthService();