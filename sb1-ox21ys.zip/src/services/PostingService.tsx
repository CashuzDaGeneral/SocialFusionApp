import { db } from '../firebase';
import { collection, addDoc, getDocs, query, where, Timestamp } from 'firebase/firestore';

const PostingService = {
  platforms: [
    { id: 'facebook', name: 'Facebook', icon: 'Facebook' },
    { id: 'instagram', name: 'Instagram', icon: 'Instagram' },
    { id: 'twitter', name: 'Twitter', icon: 'Twitter' },
    { id: 'linkedin', name: 'LinkedIn', icon: 'Linkedin' },
    { id: 'tiktok', name: 'TikTok', icon: 'TikTok' },
    { id: 'youtube', name: 'YouTube', icon: 'Youtube' },
    { id: 'twitch', name: 'Twitch', icon: 'Twitch' },
    { id: 'bigo', name: 'BiGo Live', icon: 'BiGoLive' }
  ],

  createPost: async (content: string, platforms: string[], mediaUrls?: string[]) => {
    try {
      const docRef = await addDoc(collection(db, "posts"), {
        content,
        platforms,
        mediaUrls: mediaUrls || [],
        createdAt: Timestamp.now(),
        status: 'pending'
      });
      
      // Post to each selected platform
      for (const platform of platforms) {
        await PostingService.postToPlatform(platform, content, mediaUrls);
      }

      return { success: true, message: 'Post created successfully', id: docRef.id };
    } catch (error) {
      console.error("Error creating post: ", error);
      return { success: false, message: 'Error creating post' };
    }
  },

  postToPlatform: async (platform: string, content: string, mediaUrls?: string[]) => {
    try {
      switch (platform) {
        case 'facebook':
          // Implement Facebook posting logic
          break;
        case 'instagram':
          // Implement Instagram posting logic
          break;
        case 'twitter':
          // Implement Twitter posting logic
          break;
        case 'linkedin':
          // Implement LinkedIn posting logic
          break;
        case 'tiktok':
          // Implement TikTok posting logic
          break;
        case 'youtube':
          // Implement YouTube posting logic
          break;
        case 'twitch':
          // Implement Twitch posting logic
          break;
        case 'bigo':
          // Implement BiGo Live posting logic
          break;
      }
    } catch (error) {
      console.error(`Error posting to ${platform}:`, error);
      throw error;
    }
  },

  schedulePost: async (content: string, platforms: string[], scheduledTime: Date, mediaUrls?: string[]) => {
    try {
      const docRef = await addDoc(collection(db, "scheduledPosts"), {
        content,
        platforms,
        mediaUrls: mediaUrls || [],
        scheduledTime: Timestamp.fromDate(scheduledTime),
        createdAt: Timestamp.now(),
        status: 'scheduled'
      });
      return { success: true, message: 'Post scheduled successfully', id: docRef.id };
    } catch (error) {
      console.error("Error scheduling post: ", error);
      return { success: false, message: 'Error scheduling post' };
    }
  },

  getPostAnalytics: async (postId: string) => {
    try {
      const analyticsRef = collection(db, "postAnalytics");
      const q = query(analyticsRef, where("postId", "==", postId));
      const querySnapshot = await getDocs(q);
      
      if (!querySnapshot.empty) {
        return querySnapshot.docs[0].data();
      }
      return {
        likes: 0,
        shares: 0,
        comments: 0,
        reach: 0,
        platformMetrics: {}
      };
    } catch (error) {
      console.error("Error fetching post analytics: ", error);
      return null;
    }
  },

  getSupportedPlatforms: () => {
    return PostingService.platforms;
  }
};

export default PostingService;