import { loadStripe } from '@stripe/stripe-js';
import axios from 'axios';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

class PaymentService {
  async createSubscription(priceId: string, customerId?: string) {
    try {
      const response = await axios.post('/api/create-subscription', {
        priceId,
        customerId
      });
      
      const { clientSecret, subscriptionId } = response.data;
      const stripe = await stripePromise;
      
      if (!stripe) {
        throw new Error('Stripe failed to load');
      }

      const { error } = await stripe.confirmCardPayment(clientSecret);
      
      if (error) {
        throw new Error(error.message);
      }

      return { subscriptionId };
    } catch (error) {
      console.error('Subscription creation failed:', error);
      throw error;
    }
  }

  async updateSubscription(subscriptionId: string, newPriceId: string) {
    try {
      const response = await axios.post('/api/update-subscription', {
        subscriptionId,
        newPriceId
      });
      return response.data;
    } catch (error) {
      console.error('Subscription update failed:', error);
      throw error;
    }
  }

  async cancelSubscription(subscriptionId: string) {
    try {
      const response = await axios.post('/api/cancel-subscription', {
        subscriptionId
      });
      return response.data;
    } catch (error) {
      console.error('Subscription cancellation failed:', error);
      throw error;
    }
  }

  async getPaymentMethods(customerId: string) {
    try {
      const response = await axios.get(`/api/payment-methods/${customerId}`);
      return response.data;
    } catch (error) {
      console.error('Failed to fetch payment methods:', error);
      throw error;
    }
  }

  async addPaymentMethod(paymentMethodId: string, customerId: string) {
    try {
      const response = await axios.post('/api/add-payment-method', {
        paymentMethodId,
        customerId
      });
      return response.data;
    } catch (error) {
      console.error('Failed to add payment method:', error);
      throw error;
    }
  }
}

export default new PaymentService();