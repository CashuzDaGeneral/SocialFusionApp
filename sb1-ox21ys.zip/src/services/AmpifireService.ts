import axios from 'axios';

class AmpifireService {
  private apiKey: string;
  private baseUrl: string;

  constructor() {
    this.apiKey = process.env.AMPIFIRE_API_KEY || '';
    this.baseUrl = 'https://api.ampifire.com/v1'; // Replace with actual API URL
  }

  async createContent(content: string, contentType: 'article' | 'video' | 'infographic') {
    try {
      const response = await axios.post(`${this.baseUrl}/content`, {
        content,
        contentType
      }, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`
        }
      });
      return response.data;
    } catch (error) {
      console.error('Error creating content with AmpiFire:', error);
      throw error;
    }
  }

  async distributeContent(contentId: string, platforms: string[]) {
    try {
      const response = await axios.post(`${this.baseUrl}/distribute`, {
        contentId,
        platforms
      }, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`
        }
      });
      return response.data;
    } catch (error) {
      console.error('Error distributing content with AmpiFire:', error);
      throw error;
    }
  }

  async getContentPerformance(contentId: string) {
    try {
      const response = await axios.get(`${this.baseUrl}/performance/${contentId}`, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`
        }
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching content performance from AmpiFire:', error);
      throw error;
    }
  }
}

export default new AmpifireService();