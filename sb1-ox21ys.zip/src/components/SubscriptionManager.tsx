import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Elements } from '@stripe/stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import PaymentForm from './PaymentForm';
import PaymentService from '../services/PaymentService';
import { motion } from 'framer-motion';
import { CreditCard, AlertCircle } from 'lucide-react';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const SubscriptionManager: React.FC = () => {
  const { currentUser } = useAuth();
  const [currentTier, setCurrentTier] = useState<string>('free');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [selectedTier, setSelectedTier] = useState<string | null>(null);

  useEffect(() => {
    const fetchSubscriptionStatus = async () => {
      if (currentUser) {
        try {
          // Fetch current subscription status
          setLoading(false);
        } catch (error) {
          setError('Failed to load subscription status');
          setLoading(false);
        }
      }
    };

    fetchSubscriptionStatus();
  }, [currentUser]);

  const handleUpgrade = (tier: string) => {
    setSelectedTier(tier);
    setShowPaymentForm(true);
  };

  const handlePaymentSuccess = async (subscriptionId: string) => {
    try {
      // Update user's subscription status in your database
      setCurrentTier(selectedTier!);
      setShowPaymentForm(false);
      setError(null);
    } catch (error) {
      setError('Failed to update subscription status');
    }
  };

  const handlePaymentError = (errorMessage: string) => {
    setError(errorMessage);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[200px]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="bg-white shadow-md rounded-lg p-6">
      <div className="flex items-center mb-6">
        <CreditCard className="w-6 h-6 text-purple-600 mr-2" />
        <h2 className="text-2xl font-bold">Your Subscription</h2>
      </div>

      {error && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4"
        >
          <div className="flex items-center">
            <AlertCircle className="w-5 h-5 mr-2" />
            <span>{error}</span>
          </div>
        </motion.div>
      )}

      <div className="mb-6">
        <p className="text-lg">
          Current Plan: <span className="font-semibold capitalize">{currentTier}</span>
        </p>
      </div>

      {showPaymentForm ? (
        <Elements stripe={stripePromise}>
          <PaymentForm
            priceId={selectedTier!}
            onSuccess={handlePaymentSuccess}
            onError={handlePaymentError}
          />
        </Elements>
      ) : (
        <div className="space-y-4">
          {currentTier === 'free' && (
            <>
              <button
                onClick={() => handleUpgrade('basic')}
                className="w-full bg-purple-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-purple-700 transition-colors"
              >
                Upgrade to Basic ($9.99/month)
              </button>
              <button
                onClick={() => handleUpgrade('premium')}
                className="w-full bg-purple-700 text-white px-6 py-3 rounded-lg font-semibold hover:bg-purple-800 transition-colors"
              >
                Upgrade to Premium ($24.99/month)
              </button>
              <button
                onClick={() => handleUpgrade('elite')}
                className="w-full bg-purple-800 text-white px-6 py-3 rounded-lg font-semibold hover:bg-purple-900 transition-colors"
              >
                Upgrade to Elite ($49.99/month)
              </button>
            </>
          )}

          {currentTier === 'basic' && (
            <>
              <button
                onClick={() => handleUpgrade('premium')}
                className="w-full bg-purple-700 text-white px-6 py-3 rounded-lg font-semibold hover:bg-purple-800 transition-colors"
              >
                Upgrade to Premium ($24.99/month)
              </button>
              <button
                onClick={() => handleUpgrade('elite')}
                className="w-full bg-purple-800 text-white px-6 py-3 rounded-lg font-semibold hover:bg-purple-900 transition-colors"
              >
                Upgrade to Elite ($49.99/month)
              </button>
            </>
          )}

          {currentTier === 'premium' && (
            <button
              onClick={() => handleUpgrade('elite')}
              className="w-full bg-purple-800 text-white px-6 py-3 rounded-lg font-semibold hover:bg-purple-900 transition-colors"
            >
              Upgrade to Elite ($49.99/month)
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default SubscriptionManager;