import React, { useState } from 'react';
import { useStripe, useElements, CardElement } from '@stripe/stripe-js';
import { motion } from 'framer-motion';
import { CreditCard, Lock } from 'lucide-react';
import PaymentService from '../services/PaymentService';

interface PaymentFormProps {
  priceId: string;
  onSuccess: (subscriptionId: string) => void;
  onError: (error: string) => void;
}

const PaymentForm: React.FC<PaymentFormProps> = ({ priceId, onSuccess, onError }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setLoading(true);

    try {
      const { subscriptionId } = await PaymentService.createSubscription(priceId);
      onSuccess(subscriptionId);
    } catch (error) {
      onError(error instanceof Error ? error.message : 'Payment failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-md mx-auto bg-white rounded-xl shadow-md p-8"
    >
      <div className="flex items-center mb-6">
        <CreditCard className="w-6 h-6 text-purple-600 mr-2" />
        <h2 className="text-2xl font-semibold">Payment Details</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="bg-gray-50 p-4 rounded-lg">
          <CardElement
            options={{
              style: {
                base: {
                  fontSize: '16px',
                  color: '#424770',
                  '::placeholder': {
                    color: '#aab7c4'
                  }
                },
                invalid: {
                  color: '#9e2146'
                }
              }
            }}
          />
        </div>

        <div className="flex items-center text-sm text-gray-600">
          <Lock className="w-4 h-4 mr-2" />
          <span>Your payment is secure and encrypted</span>
        </div>

        <button
          type="submit"
          disabled={!stripe || loading}
          className={`w-full bg-purple-600 text-white py-3 px-6 rounded-lg font-semibold
            ${loading ? 'opacity-50 cursor-not-allowed' : 'hover:bg-purple-700'}`}
        >
          {loading ? 'Processing...' : 'Subscribe Now'}
        </button>
      </form>
    </motion.div>
  );
};

export default PaymentForm;