import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

const StreamAnalytics = ({ data }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-xl font-semibold mb-4">Stream Analytics</h3>
      <BarChart width={600} height={300} data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="platform" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Bar dataKey="viewers" fill="#8884d8" />
        <Bar dataKey="likes" fill="#82ca9d" />
        <Bar dataKey="comments" fill="#ffc658" />
      </BarChart>
    </div>
  );
};

export default StreamAnalytics;